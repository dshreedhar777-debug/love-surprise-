function nextStep(step){
  document.querySelectorAll("div").forEach(d=>d.classList.add("hidden"));
  document.getElementById("step"+step).classList.remove("hidden");
}

function startMusic(){
  document.getElementById("bgMusic").play();
}
